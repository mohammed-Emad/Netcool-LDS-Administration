import base64
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto import Random

fileR = 'rrms.json'
def encrypt(key, source, encode=True):
    key = SHA256.new(key).digest()  # use SHA-256 over our key to get a proper-sized AES key
    IV = Random.new().read(AES.block_size)  # generate IV
    encryptor = AES.new(key, AES.MODE_CBC, IV)
    padding = AES.block_size - len(source) % AES.block_size  # calculate needed padding
    source += bytes([padding]) * padding  # Python 2.x: source += chr(padding) * padding
    data = IV + encryptor.encrypt(source)  # store the IV at the beginning and encrypt
    return base64.b64encode(data).decode("latin-1") if encode else data

def decrypt(key, source, decode=True):
    if decode:
        source = base64.b64decode(source.encode("latin-1"))
    key = SHA256.new(key).digest()  # use SHA-256 over our key to get a proper-sized AES key
    IV = source[:AES.block_size]  # extract the IV from the beginning
    decryptor = AES.new(key, AES.MODE_CBC, IV)
    data = decryptor.decrypt(source[AES.block_size:])  # decrypt
    padding = data[-1]  # pick the padding value from the end; Python 2.x: ord(data[-1])
    if data[-padding:] != bytes([padding]) * padding:  # Python 2.x: chr(padding) * padding
        raise ValueError("Invalid padding...")
    return data[:-padding]  # remove the padding
    

data     = b"okjjhuh76redr-ygjyttgeserwshtrdykugkugyutfvythf75ftrtdsweaqbcz6rt"


def jjeson(nam,ps,da_name,host,port,django_secret_key):
   jjs = {
    "Name": str(nam),
    "DB_PASSWORD": str(ps),
    "DB_Name":  str(da_name),
    "Host": str(host),
    "port": str(port),
    "SECRET_KEY": str(django_secret_key),
   }
   return jjs



Namee  = input("Enter user Name db2::")
passw  = input("Enter password db2::")
database_name  = input("Enter name your DATABASES  db2::")
host  = input("Enter your server or host  db2::")
port  = input("Enter your port database db2::")
django_secret_key = input("Enter your SECRET_KEY django or enter [y] to use [75oef^qajr2e+$!d-ssc0i5lcicx0_z$lof8*ek%@bh*c(2*t&]::")

if django_secret_key == 'y':
   django_secret_key = '75oef^qajr2e+$!d-ssc0i5lcicx0_z$lof8*ek%@bh*c(2*t&'

Namee = encrypt(Namee, data)
passw = encrypt(passw, data)
database_name = encrypt(database_name, data)
host = encrypt(host, data)
port = encrypt(port, data)
django_secret_key = encrypt(django_secret_key, data)

res = jjeson(Namee,passw,database_name,host,port,django_secret_key)
fdd = open("{}".format(fileR), 'w')
fdd.write(str(res))

for io in res:
   decrypted = decrypt(io, encrypted)
   print("dec:  {}".format(decrypted))
